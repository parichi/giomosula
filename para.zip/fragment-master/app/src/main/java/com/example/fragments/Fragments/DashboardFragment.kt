package com.example.fragments.Fragments

import androidx.fragment.app.Fragment
import com.example.fragments.R

class DashboardFragment: Fragment(R.layout.dashboard_fragment) {
}