package com.example.fragments.Fragments


import androidx.fragment.app.Fragment
import com.example.fragments.R

class SettingsFragment: Fragment(R.layout.settings_fragment) {
}